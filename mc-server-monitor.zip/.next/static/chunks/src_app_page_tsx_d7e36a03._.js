(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_54a908b9._.js",
  "static/chunks/node_modules_next_eb31a9e4._.js",
  "static/chunks/node_modules_lodash_c8d69288._.js",
  "static/chunks/node_modules_recharts_es6_8fee95d8._.js",
  "static/chunks/node_modules_778484e9._.js"
],
    source: "dynamic"
});
