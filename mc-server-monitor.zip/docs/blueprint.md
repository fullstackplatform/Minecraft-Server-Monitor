# **App Name**: Minecraft Monitor

## Core Features:

- Server Status Fetch: Fetch the current status of the Minecraft server including online status, number of players, and server MOTD (message of the day).
- Dynamic Display: Dynamically display the server status, player count, and MOTD on the web page, updating automatically.
- Player List: Show a list of currently online players with their names or avatars (if available).
- Server Address Input: Allow users to input the Minecraft server address (IP and port) to check its status. Validate the format.
- Server Icon Display: Display the server's icon (favicon) if available.

## Style Guidelines:

- Primary color: Dark green (#388E3C), evoking the lush landscapes of Minecraft.
- Background color: Very dark gray (#212121), offering a high-contrast dark theme.
- Accent color: Bright cyan (#00BCD4), to highlight important information and interactive elements.
- Font: 'Space Grotesk', a modern sans-serif font, for headlines and short text passages. For long passages of text use 'Inter'.
- Use pixel art style icons inspired by Minecraft for server status, player count, etc.
- A clean and organized layout with server information prominently displayed. Use cards or containers to group related information.
- Subtle animations for status updates (e.g., server going online/offline) and when fetching new data.