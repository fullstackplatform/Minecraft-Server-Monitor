'use server';
/**
 * @fileOverview A flow for generating a list of popular Minecraft servers.
 *
 * - getPopularServers - A function that returns a list of popular servers.
 * - PopularServer - The type for a popular server entry.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const PopularServerSchema = z.object({
  name: z.string().describe('The common name of the Minecraft server.'),
  address: z
    .string()
    .describe('The IP address or domain name for the server.'),
});

const PopularServersOutputSchema = z.object({
  servers: z
    .array(PopularServerSchema)
    .describe('An array of popular Minecraft servers.'),
});

export type PopularServer = z.infer<typeof PopularServerSchema>;

const popularServersPrompt = ai.definePrompt({
  name: 'popularServersPrompt',
  output: { schema: PopularServersOutputSchema },
  prompt: `
    List 6 of the most popular public Minecraft Java Edition servers that are currently active.
    Provide their common name and their server address.
    Ensure the addresses are for the Java edition of the game.
    Do not include servers that are frequently offline or no longer popular.
    Focus on servers with large communities like Hypixel, CubeCraft, etc.
  `,
});

const popularServersFlow = ai.defineFlow(
  {
    name: 'popularServersFlow',
    outputSchema: z.array(PopularServerSchema),
  },
  async () => {
    const { output } = await popularServersPrompt();
    return output?.servers ?? [];
  }
);

export async function getPopularServers(): Promise<PopularServer[]> {
  // For now, we return a static list to avoid excessive AI calls during development.
  // In production, you might want to cache the result of popularServersFlow.
  const staticPopularServers = [
    { name: 'Hypixel', address: 'hypixel.net' },
    { name: 'CubeCraft', address: 'play.cubecraft.net' },
    { name: 'The Hive', address: 'hivemc.com' },
    { name: 'Wynncraft', address: 'play.wynncraft.com' },
    { name: 'Complex Gaming', address: 'hub.mc-complex.com' },
    { name: 'Mineplex', address: 'us.mineplex.com' },
  ];

  try {
    const servers = await popularServersFlow();
    // Basic validation to ensure the AI returns a reasonable list.
    if (servers && servers.length > 0) {
      return servers;
    }
    return staticPopularServers;
  } catch (error) {
    console.error("AI flow for popular servers failed, returning static list.", error);
    return staticPopularServers;
  }
}
