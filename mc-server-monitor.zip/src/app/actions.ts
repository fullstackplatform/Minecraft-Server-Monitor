'use server';

import { z } from 'zod';

const ServerAddressSchema = z.string().min(3, "Server address must be at least 3 characters long.");

export interface ServerStatus {
    online: boolean;
    ip?: string;
    port?: number;
    hostname?: string;
    version?: string;
    motd?: {
        raw: string | string[];
        clean: string | string[];
    };
    players?: {
        online: number;
        max: number;
        list: { name: string }[];
    };
    favicon?: string;
    type: 'Java' | 'Bedrock' | null;
    ping?: boolean;
}

async function fetchServerStatus(url: string, serverAddress: string, type: 'Java' | 'Bedrock'): Promise<{ status: ServerStatus | null, error: string | null }> {
    try {
        const res = await fetch(url);
        
        // mcsrvstat.us can return a 500 error for various reasons, not just server offline
        // so we check the 'online' flag in the response body instead of just the status code
        const data = await res.json();
        
        if (!data.online) {
            // This is not an error, the server is just offline for this type (Java/Bedrock)
            // The main function will handle this and may try another type.
            return { status: { online: false, type: null }, error: null };
        }

        const status: ServerStatus = {
            online: data.online,
            ip: data.ip,
            port: data.port,
            hostname: data.hostname,
            version: data.version,
            motd: {
                raw: data.motd.raw,
                clean: Array.isArray(data.motd.clean) ? data.motd.clean.join('\n') : data.motd.clean,
            },
            players: {
                online: data.players.online,
                max: data.players.max,
                list: (data.players.list || []).map((p: string | { name: string }) => (typeof p === 'string' ? { name: p } : p)),
            },
            favicon: data.icon || `https://mc-heads.net/server-icon/${serverAddress}`,
            type: type,
            ping: data.debug?.ping
        };

        return { status, error: null };

    } catch (error) {
        console.error(`Error fetching from ${url}:`, error);
        // This indicates a network error or that the API itself is down.
        return { status: null, error: 'An unexpected error occurred while contacting the server status API.' };
    }
}


export async function getServerStatus(
  prevState: { status: ServerStatus | null, error: string | null, serverAddress: string | null },
  formData: FormData,
): Promise<{ status: ServerStatus | null; error: string | null; serverAddress: string | null }> {
    const serverAddress = formData.get('serverAddress') as string;

    const validation = ServerAddressSchema.safeParse(serverAddress);

    if (!validation.success) {
        return { status: null, error: validation.error.errors[0].message, serverAddress };
    }

    // First, try Java status
    const javaResult = await fetchServerStatus(`https://api.mcsrvstat.us/3/${serverAddress}`, serverAddress, 'Java');

    if (javaResult.status && javaResult.status.online) {
        return { status: javaResult.status, error: null, serverAddress };
    }

    // If Java fails or is offline, try Bedrock status
    const bedrockResult = await fetchServerStatus(`https://api.mcsrvstat.us/bedrock/3/${serverAddress}`, serverAddress, 'Bedrock');

    if (bedrockResult.status && bedrockResult.status.online) {
        return { status: bedrockResult.status, error: null, serverAddress };
    }
    
    // Check for API-level errors from the fetch attempts
    if (javaResult.error) {
        return { status: null, error: javaResult.error, serverAddress };
    }
     if (bedrockResult.error) {
        return { status: null, error: bedrockResult.error, serverAddress };
    }

    // If both are confirmed to be offline, report it.
    const offlineStatus: ServerStatus = {
        online: false,
        favicon: `https://mc-heads.net/server-icon/${serverAddress}`,
        type: null,
    };
    
    return { status: offlineStatus, error: `Server "${serverAddress}" appears to be offline for both Java and Bedrock Editions.`, serverAddress };
}

    