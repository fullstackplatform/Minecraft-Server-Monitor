'use server';

import { z } from 'zod';

const ServerAddressSchema = z.string().min(3, "Server address must be at least 3 characters long.");

export interface ServerStatus {
    online: boolean;
    ip?: string;
    port?: number;
    hostname?: string;
    version?: string;
    software?: string;
    motd?: {
        raw: string | string[];
        clean: string | string[];
    };
    players?: {
        online: number;
        max: number;
        list: { name: string }[];
    };
    favicon?: string;
    type: 'Java' | 'Bedrock' | null;
}

async function fetchServerStatus(url: string, serverAddress: string, type: 'Java' | 'Bedrock'): Promise<{ status: ServerStatus | null, error: string | null }> {
    try {
        const res = await fetch(url, { next: { revalidate: 0 } }); // Disable cache for this fetch
        
        if (!res.ok) {
            // The API returned an error (e.g., 500, 404)
            return { status: null, error: `The server status API (mcsrvstat.us) returned an error: ${res.statusText}.` };
        }

        const data = await res.json();
        
        if (!data.online) {
            // The API was reached, but the server is offline
            return { status: { online: false, type: null }, error: null };
        }

        const status: ServerStatus = {
            online: data.online,
            ip: data.ip,
            port: data.port,
            hostname: data.hostname,
            version: data.version,
            software: data.software,
            motd: {
                raw: data.motd.raw,
                clean: Array.isArray(data.motd.clean) ? data.motd.clean.join('\n') : data.motd.clean,
            },
            players: {
                online: data.players.online,
                max: data.players.max,
                list: (data.players.list || []).map((p: string | { name: string }) => (typeof p === 'string' ? { name: p } : p)),
            },
            favicon: data.icon || `https://mc-heads.net/server-icon/${serverAddress}`,
            type: type,
        };

        return { status, error: null };

    } catch (error) {
        console.error(`Error fetching from ${url}:`, error);
        // A network error occurred, or the API is down
        return { status: null, error: 'The server status API (mcsrvstat.us) could not be reached. Please try again later.' };
    }
}


export async function getServerStatus(
  prevState: { status: ServerStatus | null, error: string | null, serverAddress: string | null },
  formData: FormData,
): Promise<{ status: ServerStatus | null; error: string | null; serverAddress: string | null }> {
    const serverAddress = formData.get('serverAddress') as string;

    const validation = ServerAddressSchema.safeParse(serverAddress);

    if (!validation.success) {
        return { status: null, error: validation.error.errors[0].message, serverAddress };
    }

    const javaResult = await fetchServerStatus(`https://api.mcsrvstat.us/3/${serverAddress}`, serverAddress, 'Java');

    if (javaResult.status && javaResult.status.online) {
        return { status: javaResult.status, error: null, serverAddress };
    }

    const bedrockResult = await fetchServerStatus(`https://api.mcsrvstat.us/bedrock/3/${serverAddress}`, serverAddress, 'Bedrock');

    if (bedrockResult.status && bedrockResult.status.online) {
        return { status: bedrockResult.status, error: null, serverAddress };
    }
    
    // Prioritize showing API errors over offline messages
    if (javaResult.error) {
        return { status: null, error: javaResult.error, serverAddress };
    }
     if (bedrockResult.error) {
        return { status: null, error: bedrockResult.error, serverAddress };
    }

    // This is only reached if both checks return `online: false` without any API errors
    const offlineStatus: ServerStatus = {
        online: false,
        favicon: `https://mc-heads.net/server-icon/${serverAddress}`,
        type: null,
    };
    
    return { status: offlineStatus, error: `Server "${serverAddress}" appears to be offline for both Java and Bedrock Editions.`, serverAddress };
}
