'use server';

import { z } from 'zod';

const ServerAddressSchema = z.string().min(3, "Server address must be at least 3 characters long.");

export interface ServerStatus {
    online: boolean;
    version?: string;
    motd?: {
        raw: string | string[];
        clean: string | string[];
    };
    players?: {
        online: number;
        max: number;
        list: { name: string }[];
    };
    favicon?: string;
}

async function fetchServerStatus(url: string, serverAddress: string): Promise<{ status: ServerStatus | null, error: string | null }> {
    try {
        const res = await fetch(url);
        
        if (!res.ok) {
            return { status: null, error: `Failed to fetch server status. API returned status: ${res.status}` };
        }

        const data = await res.json();
        
        if (!data.online) {
            return { status: null, error: `Server appears to be offline at ${url}.` };
        }

        const status: ServerStatus = {
            online: data.online,
            version: data.version,
            motd: {
                raw: data.motd.raw,
                clean: Array.isArray(data.motd.clean) ? data.motd.clean.join('\n') : data.motd.clean,
            },
            players: {
                online: data.players.online,
                max: data.players.max,
                list: (data.players.list || []).map((name: string) => ({ name })),
            },
            favicon: data.icon || `https://mc-heads.net/server-icon/${serverAddress}`,
        };

        return { status, error: null };

    } catch (error) {
        console.error(`Error fetching from ${url}:`, error);
        return { status: null, error: 'An unexpected error occurred while fetching the server status.' };
    }
}


export async function getServerStatus(
  prevState: { status: ServerStatus | null, error: string | null, serverAddress: string | null },
  formData: FormData,
): Promise<{ status: ServerStatus | null; error: string | null; serverAddress: string | null }> {
    const serverAddress = formData.get('serverAddress') as string;

    const validation = ServerAddressSchema.safeParse(serverAddress);

    if (!validation.success) {
        return { status: null, error: validation.error.errors[0].message, serverAddress };
    }

    // First, try Java status
    const javaResult = await fetchServerStatus(`https://api.mcsrvstat.us/3/${serverAddress}`, serverAddress);

    if (javaResult.status) {
        return { status: javaResult.status, error: null, serverAddress };
    }

    // If Java fails, try Bedrock status
    const bedrockResult = await fetchServerStatus(`https://api.mcsrvstat.us/bedrock/3/${serverAddress}`, serverAddress);

    if (bedrockResult.status) {
        return { status: bedrockResult.status, error: null, serverAddress };
    }

    // If both fail, report as offline
    const offlineStatus: ServerStatus = {
        online: false,
        favicon: `https://mc-heads.net/server-icon/${serverAddress}`,
    };
    return { status: offlineStatus, error: `Server "${serverAddress}" appears to be offline for both Java and Bedrock Editions.`, serverAddress };
}
