'use client';

import { useActionState } from 'react';
import { useFormStatus } from 'react-dom';
import Image from 'next/image';

import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import {
  PickaxeIcon,
  ServerIcon,
  UsersIcon,
  StatusOnlineIcon,
  StatusOfflineIcon,
} from '@/components/icons';
import { getServerStatus, type ServerStatus } from '@/app/actions';
import { cn } from '@/lib/utils';
import { Separator } from '@/components/ui/separator';

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending} className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-base px-6 py-6 shadow-lg shadow-primary/20">
      {pending ? (
        <>
          <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Pinging...
        </>
      ) : (
        <>
          <ServerIcon className="mr-2 h-5 w-5" />
          Check Status
        </>
      )}
    </Button>
  );
}

function ServerStatusCard({ status, serverAddress }: { status: ServerStatus, serverAddress: string }) {
  return (
    <Card className="overflow-hidden shadow-2xl border-border/20 bg-card/80 backdrop-blur-sm">
      <CardHeader className="flex flex-col sm:flex-row items-start gap-6 p-6">
        {status.favicon && (
          <Image
            src={status.favicon}
            alt="Server icon"
            width={80}
            height={80}
            className="rounded-lg border-2 border-border/40 aspect-square"
            unoptimized
          />
        )}
        <div className="w-full pt-1">
          <CardTitle className="font-headline text-3xl text-foreground">{serverAddress}</CardTitle>
          <CardDescription className="text-muted-foreground text-lg font-mono">{status.motd?.clean}</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="p-6 grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
        <div className="p-4 rounded-lg bg-background/50 flex flex-col items-center justify-center gap-2">
            <h3 className="text-sm font-semibold text-muted-foreground">Status</h3>
            <div className="flex items-center justify-center gap-2">
                {status.online ? <StatusOnlineIcon /> : <StatusOfflineIcon />}
                <span className={`font-bold text-lg ${status.online ? 'text-[hsl(var(--status-online))]' : 'text-[hsl(var(--status-offline))]'}`}>
                    {status.online ? 'Online' : 'Offline'}
                </span>
            </div>
        </div>
        <div className="p-4 rounded-lg bg-background/50 flex flex-col items-center justify-center gap-2">
            <h3 className="text-sm font-semibold text-muted-foreground flex items-center justify-center gap-2"><UsersIcon className="w-4 h-4"/> Players</h3>
            <p className="font-bold text-lg font-mono">
                {status.players?.online ?? 'N/A'}<span className="text-muted-foreground"> / {status.players?.max ?? 'N/A'}</span>
            </p>
        </div>
        <div className="p-4 rounded-lg bg-background/50 flex flex-col items-center justify-center gap-2">
            <h3 className="text-sm font-semibold text-muted-foreground">Version</h3>
            <p className="font-bold text-lg font-mono">{status.version ?? 'N/A'}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function PlayerListCard({ players }: { players?: ServerStatus['players'] }) {
    if (!players || players.online === 0) {
        return (
            <Card className="bg-card/80 backdrop-blur-sm border-border/20 shadow-xl">
                <CardHeader>
                    <CardTitle className="font-headline text-2xl">Players</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">No players are currently online.</p>
                </CardContent>
            </Card>
        );
    }
  return (
    <Card className="shadow-2xl border-border/20 bg-card/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="font-headline text-2xl">Players Online ({players.online})</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-x-4 gap-y-6">
          {(players.list || []).map((player, index) => (
            <div key={index} className="flex flex-col items-center gap-2 p-2 rounded-lg transition-colors hover:bg-background/50">
                <div className="relative">
                    <Image
                        src={`https://mc-heads.net/avatar/${player.name}/64`}
                        alt={player.name}
                        width={64}
                        height={64}
                        className="rounded-md shadow-md"
                        unoptimized
                    />
                    <div className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 w-max">
                        <span className="font-mono text-xs font-semibold text-white bg-black/50 px-2 py-0.5 rounded-sm backdrop-blur-sm">
                            {player.name}
                        </span>
                    </div>
                </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function StatusSkeleton() {
  return (
    <div className="space-y-6">
      <Card className="overflow-hidden">
        <CardHeader className="flex flex-row items-start gap-6 p-6">
            <Skeleton className="w-20 h-20 rounded-lg" />
            <div className="w-full space-y-3 pt-1">
                <Skeleton className="h-8 w-1/2" />
                <Skeleton className="h-6 w-3/4" />
            </div>
        </CardHeader>
        <CardContent className="p-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Skeleton className="h-20 w-full rounded-lg" />
            <Skeleton className="h-20 w-full rounded-lg" />
            <Skeleton className="h-20 w-full rounded-lg" />
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
            <Skeleton className="h-8 w-1/4" />
        </CardHeader>
        <CardContent className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-x-4 gap-y-6">
            {Array.from({ length: 10 }).map((_, i) => (
                <div key={i} className="flex flex-col items-center gap-3">
                    <Skeleton className="w-16 h-16 rounded-md" />
                    <Skeleton className="h-4 w-20" />
                </div>
            ))}
        </CardContent>
      </Card>
    </div>
  );
}

function Results({ state }: { state: { status: ServerStatus | null, error: string | null, serverAddress: string | null }}) {
    const { pending } = useFormStatus();

    if (pending) {
        return <StatusSkeleton />;
    }
    
    if (state.status) {
        return (
          <div className="space-y-6 animate-in fade-in-0 duration-700">
            <ServerStatusCard status={state.status} serverAddress={state.serverAddress!} />
            {state.status.online && <PlayerListCard players={state.status.players} />}
          </div>
        );
    }
    
    if (state.error) {
        return (
            <Alert variant="destructive" className="animate-in fade-in bg-destructive/10 border-destructive/30 text-destructive-foreground">
                <AlertTitle className="font-headline">Error</AlertTitle>
                <AlertDescription>{state.error}</AlertDescription>
            </Alert>
        );
    }

    return (
        <div className="text-center py-20 border-2 border-dashed border-border/30 rounded-2xl">
            <ServerIcon className="mx-auto h-16 w-16 text-muted-foreground/30"/>
            <p className="mt-6 text-lg text-muted-foreground font-headline">Enter a server address to get started</p>
        </div>
    );
}

export default function Home() {
  const initialState = { status: null, error: null, serverAddress: null };
  const [state, formAction] = useActionState(getServerStatus, initialState);

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <div 
        className="absolute inset-0 -z-10 h-full w-full bg-background 
        bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(30,144,255,0.3),rgba(255,255,255,0))]"
      />
      
      <div className="w-full max-w-5xl mx-auto space-y-8">
        <header className="text-center space-y-4 py-8">
          <div className="inline-flex items-center gap-4">
            <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
              <PickaxeIcon className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-4xl sm:text-5xl font-headline font-bold tracking-tighter">
              Minecraft Server Monitor
            </h1>
          </div>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Instantly check the status, player count, and MOTD for any Java Edition Minecraft server.
          </p>
        </header>

        <main className="grid grid-cols-1 gap-8">
          <form action={formAction} className="space-y-8">
            <Card className="shadow-2xl border-border/20 sticky top-4 z-10 bg-card/60 backdrop-blur-xl">
                <CardContent className="p-4 sm:p-6">
                    <label htmlFor='serverAddress' className="text-sm font-medium text-muted-foreground mb-2 block ml-1">Server Address</label>
                    <div className="flex flex-col sm:flex-row items-center gap-4">
                        <Input
                            id="serverAddress"
                            name="serverAddress"
                            defaultValue={state.serverAddress ?? ''}
                            placeholder="e.g., hypixel.net"
                            className="text-base flex-grow h-16 px-4 bg-background/80"
                            aria-label="Server Address"
                        />
                        <SubmitButton />
                    </div>
                    {state.error && !state.status && <p className="text-sm font-medium text-destructive mt-2">{state.error}</p>}
                </CardContent>
            </Card>

            <Separator className="bg-border/20" />

            <Results state={state} />
          </form>
        </main>
      </div>

      <footer className="py-8 mt-auto text-center text-muted-foreground text-sm">
        <p>Built with the love of the craft. 💎</p>
      </footer>
    </div>
  );
}
