'use client';

import { useActionState, useRef, useEffect, useState } from 'react';
import { useFormStatus } from 'react-dom';
import Image from 'next/image';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';


import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  PickaxeIcon,
  ServerIcon,
  UsersIcon,
  StatusOnlineIcon,
  StatusOfflineIcon,
  ClockIcon,
  Share2Icon,
  RefreshCwIcon,
  DefaultServerIcon,
  StarIcon,
  CopyIcon,
  Trash2Icon,
  EditIcon,
  HistoryIcon,
  CogIcon,
} from '@/components/icons';
import { getServerStatus, type ServerStatus } from '@/app/actions';
import { getPopularServers, PopularServer } from '@/ai/flows/popular-servers';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';

const HISTORY_KEY = 'minecraft-server-history';
const FAVORITES_KEY = 'minecraft-server-favorites-v2';
const PLAYER_HISTORY_KEY = 'minecraft-player-history';
const MAX_HISTORY_LENGTH = 5;

export type PlayerHistoryPoint = {
  time: string;
  players: number;
};

export type FavoriteServer = {
  address: string;
  name: string;
};


function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending} className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-base px-6 py-6 shadow-lg shadow-primary/20">
      {pending ? (
        <>
          <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Pinging...
        </>
      ) : (
        <>
          <ServerIcon className="mr-2 h-5 w-5" />
          Check Status
        </>
      )}
    </Button>
  );
}

function ServerStatusCard({ 
    status, 
    serverAddress, 
    onRefresh, 
    isRefreshing, 
    onAutoRefreshToggle, 
    isAutoRefreshing, 
    onFavoriteToggle, 
    isFavorited,
    playerHistory
}: { 
    status: ServerStatus, 
    serverAddress: string, 
    onRefresh: () => void, 
    isRefreshing: boolean, 
    onAutoRefreshToggle: (checked: boolean) => void, 
    isAutoRefreshing: boolean, 
    onFavoriteToggle: () => void, 
    isFavorited: boolean,
    playerHistory: PlayerHistoryPoint[]
}) {
  const displayAddress = status.hostname || serverAddress;
  const { toast } = useToast();

  const handleShare = () => {
    const url = new URL(window.location.href);
    url.searchParams.set('server', serverAddress);
    navigator.clipboard.writeText(url.toString());
    toast({
      title: "Link Copied!",
      description: "A shareable link has been copied to your clipboard.",
    });
  };
  
  const handleCopyIp = () => {
    if (status.ip && status.port) {
      navigator.clipboard.writeText(`${status.ip}:${status.port}`);
      toast({
        title: "IP Address Copied!",
        description: `${status.ip}:${status.port} has been copied.`,
      });
    }
  }

  return (
    <Card className="overflow-hidden shadow-2xl border-border/20 bg-card/80 backdrop-blur-sm">
      <CardHeader className="flex flex-col sm:flex-row items-start gap-6 p-6">
        {status.favicon && (
          <Image
            src={status.favicon}
            alt="Server icon"
            width={80}
            height={80}
            className="rounded-lg border-2 border-border/40 aspect-square"
            unoptimized
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.onerror = null; // prevents looping
              target.src = '/default-server-icon.svg';
            }}
          />
        )}
        <div className="w-full pt-1">
          <div className="flex flex-wrap items-center gap-4 mb-2">
            <CardTitle className="font-headline text-3xl text-foreground">{displayAddress}</CardTitle>
            {status.type && (
                <Badge variant={status.type === 'Java' ? 'default' : 'secondary'} className="text-sm">
                {status.type} Edition
                </Badge>
            )}
          </div>
          <CardDescription className="text-muted-foreground text-lg font-mono whitespace-pre-wrap">{status.motd?.clean}</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="p-6 pt-0 grid grid-cols-2 lg:grid-cols-4 gap-4 text-center">
        <div className="p-4 rounded-lg bg-background/50 flex flex-col items-center justify-center gap-2">
            <h3 className="text-sm font-semibold text-muted-foreground flex items-center justify-center gap-2">Status</h3>
            <div className="flex items-center justify-center gap-2">
                {status.online ? <StatusOnlineIcon /> : <StatusOfflineIcon />}
                <span className={`font-bold text-lg ${status.online ? 'text-[hsl(var(--status-online))]' : 'text-[hsl(var(--status-offline))]'}`}>
                    {status.online ? 'Online' : 'Offline'}
                </span>
            </div>
        </div>
        <div className="p-4 rounded-lg bg-background/50 flex flex-col items-center justify-center gap-2">
            <h3 className="text-sm font-semibold text-muted-foreground flex items-center justify-center gap-2"><UsersIcon className="w-4 h-4"/> Players</h3>
            <p className="font-bold text-lg font-mono">
                {status.players?.online ?? 'N/A'}<span className="text-muted-foreground"> / {status.players?.max ?? 'N/A'}</span>
            </p>
        </div>
        <div className="p-4 rounded-lg bg-background/50 flex flex-col items-center justify-center gap-2">
            <h3 className="text-sm font-semibold text-muted-foreground flex items-center justify-center gap-2"><PickaxeIcon className="w-4 h-4"/> Version</h3>
            <p className="font-bold text-lg font-mono">{status.version ?? 'N/A'}</p>
        </div>
        <div className="p-4 rounded-lg bg-background/50 flex flex-col items-center justify-center gap-2">
            <h3 className="text-sm font-semibold text-muted-foreground flex items-center justify-center gap-2"><CogIcon className="w-4 h-4"/> Software</h3>
            <p className="font-bold text-lg font-mono">{status.software ?? 'N/A'}</p>
        </div>
        <div className="p-4 rounded-lg bg-background/50 flex flex-col items-center justify-center gap-2 relative group col-span-2 lg:col-span-4">
            <h3 className="text-sm font-semibold text-muted-foreground">IP Address</h3>
            <p className="font-bold text-lg font-mono break-all">{status.ip && status.port ? `${status.ip}:${status.port}` : 'N/A'}</p>
            {status.ip && status.port && (
              <Button variant="ghost" size="icon" className="absolute top-1 right-1 h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity" onClick={handleCopyIp}>
                <CopyIcon className="h-4 w-4"/>
              </Button>
            )}
        </div>
      </CardContent>
      {playerHistory && playerHistory.length > 1 && (
        <CardContent className="p-6 pt-0">
          <h3 className="text-lg font-headline mb-4 text-center">Recent Player Count</h3>
          <div className="w-full h-48">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={playerHistory} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border) / 0.5)" />
                <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip
                    contentStyle={{
                        backgroundColor: 'hsl(var(--card))',
                        borderColor: 'hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                    }}
                    labelStyle={{ color: 'hsl(var(--foreground))' }}
                />
                <Line type="monotone" dataKey="players" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      )}
       <CardFooter className="bg-background/30 px-6 py-3 flex-wrap gap-4 justify-between">
            <div className="flex items-center space-x-2">
                <Switch id="auto-refresh" onCheckedChange={onAutoRefreshToggle} checked={isAutoRefreshing} />
                <Label htmlFor="auto-refresh" className="text-sm text-muted-foreground">Auto-refresh every 30s</Label>
            </div>
            <div className="flex gap-2">
                 <Button variant="outline" size="sm" onClick={onRefresh} disabled={isRefreshing}>
                    <RefreshCwIcon className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                    {isRefreshing ? 'Refreshing...' : 'Refresh'}
                </Button>
                <Button variant="outline" size="sm" onClick={handleShare}>
                    <Share2Icon className="h-4 w-4 mr-2" />
                    Share
                </Button>
                <Button variant={isFavorited ? "default" : "outline"} size="sm" onClick={onFavoriteToggle}>
                    <StarIcon className={`h-4 w-4 mr-2 ${isFavorited ? 'text-yellow-400 fill-yellow-400' : ''}`} />
                    {isFavorited ? 'Favorited' : 'Favorite'}
                </Button>
            </div>
        </CardFooter>
    </Card>
  );
}

function PlayerListCard({ players }: { players?: ServerStatus['players'] }) {
    if (!players || players.online === 0 || !players.list || players.list.length === 0) {
        return (
            <Card className="bg-card/80 backdrop-blur-sm border-border/20 shadow-xl">
                <CardHeader>
                    <CardTitle className="font-headline text-2xl">Players</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">No players are currently online.</p>
                </CardContent>
            </Card>
        );
    }
  return (
    <Card className="shadow-2xl border-border/20 bg-card/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="font-headline text-2xl">Players Online ({players.online})</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-x-4 gap-y-6 pt-5">
          {players.list.map((player, index) => (
            <div key={index} className="flex flex-col items-center gap-2 p-2 rounded-lg transition-colors hover:bg-background/50">
                <div className="relative">
                    <Image
                        src={`https://mc-heads.net/avatar/${player.name}/64`}
                        alt={player.name}
                        width={64}
                        height={64}
                        className="rounded-md shadow-md"
                        unoptimized
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.onerror = null;
                          target.src = '/default-player-icon.svg';
                        }}
                    />
                    <div className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 w-max">
                        <span className="font-mono text-xs font-semibold text-white bg-black/50 px-2 py-0.5 rounded-sm backdrop-blur-sm border border-black/20">
                            {player.name}
                        </span>
                    </div>
                </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function StatusSkeleton() {
  return (
    <div className="space-y-6">
      <Card className="overflow-hidden">
        <CardHeader className="flex flex-row items-start gap-6 p-6">
            <Skeleton className="w-20 h-20 rounded-lg" />
            <div className="w-full space-y-3 pt-1">
                <Skeleton className="h-8 w-1/2" />
                <Skeleton className="h-6 w-3/4" />
            </div>
        </CardHeader>
        <CardContent className="p-6 pt-0 grid grid-cols-2 lg:grid-cols-4 gap-4">
            <Skeleton className="h-20 w-full rounded-lg" />
            <Skeleton className="h-20 w-full rounded-lg" />
            <Skeleton className="h-20 w-full rounded-lg" />
            <Skeleton className="h-20 w-full rounded-lg" />
            <Skeleton className="h-20 w-full rounded-lg col-span-2 lg:col-span-4" />
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
            <Skeleton className="h-8 w-1/4" />
        </CardHeader>
        <CardContent className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-x-4 gap-y-6 pt-5">
            {Array.from({ length: 10 }).map((_, i) => (
                <div key={i} className="flex flex-col items-center gap-2">
                    <Skeleton className="w-16 h-16 rounded-md" />
                    <Skeleton className="h-4 w-20 mt-1" />
                </div>
            ))}
        </CardContent>
      </Card>
    </div>
  );
}

function Results({ state, onRefresh, isRefreshing, onAutoRefreshToggle, isAutoRefreshing, onFavoriteToggle, isFavorited, playerHistory }: { state: { status: ServerStatus | null, error: string | null, serverAddress: string | null }, onRefresh: () => void, isRefreshing: boolean, onAutoRefreshToggle: (c:boolean) => void, isAutoRefreshing: boolean, onFavoriteToggle: () => void, isFavorited: boolean, playerHistory: PlayerHistoryPoint[] }) {
    const { pending } = useFormStatus();

    if (pending) {
        return <StatusSkeleton />;
    }
    
    if (state.status?.online) {
        return (
          <div className="space-y-6 animate-in fade-in-0 duration-700">
            <ServerStatusCard status={state.status} serverAddress={state.serverAddress!} onRefresh={onRefresh} isRefreshing={isRefreshing} onAutoRefreshToggle={onAutoRefreshToggle} isAutoRefreshing={isAutoRefreshing} onFavoriteToggle={onFavoriteToggle} isFavorited={isFavorited} playerHistory={playerHistory} />
            <PlayerListCard players={state.status.players} />
          </div>
        );
    }
    
    if (state.error || (state.serverAddress && !state.status?.online)) {
        const defaultError = `Server "${state.serverAddress}" appears to be offline for both Java and Bedrock Editions.`;
        const isOfflineError = (state.error === null || state.error === defaultError);
        const error = state.error || defaultError;

        return (
            <Card className="bg-card/80 backdrop-blur-sm border-border/20 shadow-xl animate-in fade-in-0">
                <CardHeader className="flex flex-row items-center gap-4">
                    {state.serverAddress && (
                         <Image
                            src={`https://mc-heads.net/server-icon/${state.serverAddress}`}
                            alt="Server icon"
                            width={48}
                            height={48}
                            className="rounded-lg"
                            unoptimized
                            onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.onerror = null; 
                                target.src = '/default-server-icon.svg';
                            }}
                        />
                    )}
                    <div>
                        <CardTitle className="font-headline">{isOfflineError ? 'Server Offline' : 'Connection Failed'}</CardTitle>
                        <CardDescription className="text-muted-foreground">{state.serverAddress}</CardDescription>
                    </div>
                </CardHeader>
                <CardContent>
                    <p className="text-destructive-foreground/80">{error}</p>
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="text-center py-20 border-2 border-dashed border-border/30 rounded-2xl">
            <ServerIcon className="mx-auto h-16 w-16 text-muted-foreground/30"/>
            <p className="mt-6 text-lg text-muted-foreground font-headline">Enter a server address to get started</p>
        </div>
    );
}

function ServerHistory({ history, onServerSelect, onClearHistory }: { history: string[], onServerSelect: (address: string) => void, onClearHistory: () => void }) {
    if (history.length === 0) {
        return null;
    }

    return (
        <Card className="shadow-2xl border-border/20 bg-card/60 backdrop-blur-xl">
            <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <CardTitle className="font-headline text-2xl">History</CardTitle>
                    <CardDescription>Recently checked servers.</CardDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={onClearHistory}>Clear</Button>
            </CardHeader>
            <CardContent>
                 <div className="flex flex-col gap-2">
                    {history.map((server) => (
                        <Button
                            key={server}
                            variant="outline"
                            className="justify-start h-14 gap-4 bg-background/50 hover:bg-background"
                            onClick={() => onServerSelect(server)}
                        >
                             <Image
                                src={`https://mc-heads.net/server-icon/${server}`}
                                alt={`${server} icon`}
                                width={24}
                                height={24}
                                className="rounded-md"
                                unoptimized
                                onError={(e) => {
                                    const target = e.target as HTMLImageElement;
                                    target.onerror = null; 
                                    target.src = '/default-server-icon.svg';
                                }}
                            />
                            <span className="font-bold font-mono">{server}</span>
                        </Button>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}

function EditFavoriteDialog({ server, onSave, onRemove }: { server: FavoriteServer, onSave: (address: string, newName: string) => void, onRemove: (address: string) => void }) {
    const [name, setName] = useState(server.name);
    const [open, setOpen] = useState(false);

    const handleSave = () => {
        onSave(server.address, name);
        setOpen(false);
    };
    
    const handleRemove = () => {
        onRemove(server.address);
        setOpen(false);
    }

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="h-14 w-14 group-hover:opacity-100 md:opacity-0 transition-opacity">
                    <EditIcon className="h-5 w-5 text-muted-foreground/60 group-hover:text-accent-foreground transition-colors" />
                </Button>
            </DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Edit Favorite</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="name" className="text-right">Name</Label>
                        <Input id="name" value={name} onChange={(e) => setName(e.target.value)} className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                         <Label className="text-right">Address</Label>
                         <p className="col-span-3 font-mono text-sm text-muted-foreground">{server.address}</p>
                    </div>
                </div>
                <DialogFooter className="justify-between sm:justify-between">
                     <Button variant="destructive" onClick={handleRemove}>
                        <Trash2Icon className="mr-2 h-4 w-4" />
                        Remove
                    </Button>
                    <Button onClick={handleSave}>Save</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}


function FavoriteServers({ favorites, onServerSelect, onSaveFavorite, onRemoveFavorite }: { favorites: FavoriteServer[], onServerSelect: (address: string) => void, onSaveFavorite: (address: string, newName: string) => void, onRemoveFavorite: (address: string) => void }) {
    if (favorites.length === 0) {
        return null;
    }

    return (
        <Card className="shadow-2xl border-border/20 bg-card/60 backdrop-blur-xl">
            <CardHeader>
                <CardTitle className="font-headline text-2xl">Favorites</CardTitle>
                <CardDescription>Your favorite servers for quick access.</CardDescription>
            </CardHeader>
            <CardContent>
                 <div className="flex flex-col gap-2">
                    {favorites.map((server) => (
                        <div key={server.address} className="flex gap-2 group">
                          <Button
                              variant="outline"
                              className="justify-start h-14 gap-4 bg-background/50 hover:bg-background flex-grow"
                              onClick={() => onServerSelect(server.address)}
                          >
                              <Image
                                  src={`https://mc-heads.net/server-icon/${server.address}`}
                                  alt={`${server.name} icon`}
                                  width={24}
                                  height={24}
                                  className="rounded-md"
                                  unoptimized
                                  onError={(e) => {
                                      const target = e.target as HTMLImageElement;
                                      target.onerror = null;
                                      target.src = '/default-server-icon.svg';
                                  }}
                              />
                              <div className="flex flex-col items-start text-left">
                                <span className="font-bold">{server.name}</span>
                                <span className="text-xs text-muted-foreground font-mono">{server.address}</span>
                              </div>
                          </Button>
                          <EditFavoriteDialog server={server} onSave={onSaveFavorite} onRemove={onRemoveFavorite} />
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}


function PopularServers({ onServerSelect }: { onServerSelect: (address: string) => void }) {
    const [popularServers, setPopularServers] = useState<PopularServer[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function loadServers() {
            try {
                const servers = await getPopularServers();
                setPopularServers(servers);
            } catch (error) {
                console.error("Failed to load popular servers:", error);
            } finally {
                setLoading(false);
            }
        }
        loadServers();
    }, []);

    return (
        <Card className="shadow-2xl border-border/20 bg-card/60 backdrop-blur-xl">
            <CardHeader>
                <CardTitle className="font-headline text-2xl">Popular Servers</CardTitle>
                <CardDescription>Click a server to check its status. This list is dynamically generated by AI!</CardDescription>
            </CardHeader>
            <CardContent>
                {loading ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                        {Array.from({ length: 6 }).map((_, i) => (
                            <Skeleton key={i} className="h-14 w-full" />
                        ))}
                    </div>
                ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                        {popularServers.map((server) => (
                            <Button
                                key={server.name}
                                variant="outline"
                                className="justify-start h-14 gap-4 bg-background/50 hover:bg-background"
                                onClick={() => onServerSelect(server.address)}
                            >
                                <Image 
                                    src={`https://mc-heads.net/server-icon/${server.address}`} 
                                    alt={`${server.name} icon`}
                                    width={24}
                                    height={24}
                                    className="rounded-md"
                                    unoptimized
                                    onError={(e) => {
                                        const target = e.target as HTMLImageElement;
                                        target.onerror = null; 
                                        target.src = '/default-server-icon.svg';
                                    }}
                                />
                                <div className="flex flex-col items-start">
                                    <span className="font-bold">{server.name}</span>
                                    <span className="text-xs text-muted-foreground font-mono">{server.address}</span>
                                </div>
                            </Button>
                        ))}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}


export default function Home() {
  const initialState = { status: null, error: null, serverAddress: null };
  const [state, formAction] = useActionState(getServerStatus, initialState);
  const formRef = useRef<HTMLFormElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { pending } = useFormStatus();

  const [history, setHistory] = useState<string[]>([]);
  const [favorites, setFavorites] = useState<FavoriteServer[]>([]);
  const [isAutoRefreshing, setIsAutoRefreshing] = useState(false);
  const autoRefreshInterval = useRef<NodeJS.Timeout | null>(null);
  const [playerHistory, setPlayerHistory] = useState<PlayerHistoryPoint[]>([]);

  // Load history & favorites from localStorage on initial render
  useEffect(() => {
    try {
      const storedHistory = localStorage.getItem(HISTORY_KEY);
      if (storedHistory) setHistory(JSON.parse(storedHistory));

      const storedFavorites = localStorage.getItem(FAVORITES_KEY);
      if (storedFavorites) setFavorites(JSON.parse(storedFavorites));

    } catch (error) {
      console.error("Could not parse data from localStorage:", error);
    }
  }, []);

  // Handle auto-refresh toggling
  useEffect(() => {
      if (isAutoRefreshing && state.serverAddress) {
          autoRefreshInterval.current = setInterval(() => {
              formRef.current?.requestSubmit();
          }, 30000);
      } else {
          if (autoRefreshInterval.current) {
              clearInterval(autoRefreshInterval.current);
              autoRefreshInterval.current = null;
          }
      }
      return () => {
          if (autoRefreshInterval.current) {
              clearInterval(autoRefreshInterval.current);
          }
      };
  }, [isAutoRefreshing, state.serverAddress]);

  const handleAutoRefreshToggle = (checked: boolean) => {
    setIsAutoRefreshing(checked);
    if (!checked && autoRefreshInterval.current) {
        clearInterval(autoRefreshInterval.current);
        autoRefreshInterval.current = null;
    }
    // Clear player history when auto-refresh is turned off
    if (!checked) {
        setPlayerHistory([]);
        localStorage.removeItem(PLAYER_HISTORY_KEY);
    }
  };

  // Handle URL param for sharing
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const serverAddressFromUrl = params.get('server');
    if (serverAddressFromUrl && inputRef.current) {
      inputRef.current.value = serverAddressFromUrl;
      formRef.current?.requestSubmit();
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  // Update history when a new server is successfully checked
  useEffect(() => {
    if (state.status?.online && state.serverAddress) {
      // Update history
      setHistory(prevHistory => {
        const newHistory = [state.serverAddress!, ...prevHistory.filter(h => h !== state.serverAddress)];
        const trimmedHistory = newHistory.slice(0, MAX_HISTORY_LENGTH);
        localStorage.setItem(HISTORY_KEY, JSON.stringify(trimmedHistory));
        return trimmedHistory;
      });

      // Update player count history if auto-refreshing
      if (isAutoRefreshing) {
        const now = new Date();
        const newPoint: PlayerHistoryPoint = {
            time: `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`,
            players: state.status.players?.online ?? 0
        };

        setPlayerHistory(prev => {
            const newHistory = [...prev, newPoint].slice(-20); // Keep last 20 data points
            localStorage.setItem(PLAYER_HISTORY_KEY, JSON.stringify({address: state.serverAddress, data: newHistory}));
            return newHistory;
        });
      }
    }
  }, [state.status, state.serverAddress, isAutoRefreshing]);

  // Load player history from local storage if it matches the current server
  useEffect(() => {
      if (state.serverAddress) {
        try {
            const storedPlayerHistory = localStorage.getItem(PLAYER_HISTORY_KEY);
            if (storedPlayerHistory) {
                const parsed = JSON.parse(storedPlayerHistory);
                if (parsed.address === state.serverAddress) {
                    setPlayerHistory(parsed.data);
                } else {
                    // Clear if it's for a different server
                    setPlayerHistory([]);
                    localStorage.removeItem(PLAYER_HISTORY_KEY);
                }
            }
        } catch (e) {
            setPlayerHistory([]);
        }
      } else {
          setPlayerHistory([]);
      }
  }, [state.serverAddress]);

  const handleToggleFavorite = () => {
    if (!state.serverAddress) return;
    setFavorites(prevFavorites => {
      const isFavorited = prevFavorites.some(f => f.address === state.serverAddress);
      let newFavorites;
      if (isFavorited) {
        newFavorites = prevFavorites.filter(fav => fav.address !== state.serverAddress);
      } else {
        newFavorites = [{ address: state.serverAddress!, name: state.serverAddress! }, ...prevFavorites];
      }
      localStorage.setItem(FAVORITES_KEY, JSON.stringify(newFavorites));
      return newFavorites;
    });
  };

  const handleSaveFavorite = (address: string, newName: string) => {
    setFavorites(prev => {
        const newFavorites = prev.map(fav => fav.address === address ? { ...fav, name: newName } : fav);
        localStorage.setItem(FAVORITES_KEY, JSON.stringify(newFavorites));
        return newFavorites;
    })
  };

  const handleRemoveFavorite = (address: string) => {
      setFavorites(prevFavorites => {
          const newFavorites = prevFavorites.filter(fav => fav.address !== address);
          localStorage.setItem(FAVORITES_KEY, JSON.stringify(newFavorites));
          return newFavorites;
      });
  };

  const handleServerSelect = (address: string) => {
    if (inputRef.current) {
        inputRef.current.value = address;
    }
    // When a new server is selected, clear player history for the old one
    if (state.serverAddress !== address) {
        setPlayerHistory([]);
        localStorage.removeItem(PLAYER_HISTORY_KEY);
    }
    formRef.current?.requestSubmit();
  };

  const handleClearHistory = () => {
    localStorage.removeItem(HISTORY_KEY);
    setHistory([]);
  };
  
  const handleRefresh = () => {
    if (state.serverAddress) {
      handleServerSelect(state.serverAddress);
    }
  };


  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <div 
        className="absolute inset-0 -z-10 h-full w-full bg-background 
        bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(30,144,255,0.3),rgba(255,255,255,0))]"
      />
      
      <div className="w-full max-w-5xl mx-auto space-y-8">
        <header className="text-center space-y-4 py-8">
          <div className="inline-flex items-center gap-4">
            <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
              <PickaxeIcon className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-4xl sm:text-5xl font-headline font-bold tracking-tighter">
              Minecraft Server Monitor
            </h1>
          </div>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Instantly check the status, player count, and MOTD for any Java or Bedrock Edition Minecraft server.
          </p>
        </header>

        <main className="grid grid-cols-1 gap-8">
          <form ref={formRef} action={formAction} className="space-y-8">
            <Card className="shadow-2xl border-border/20 sticky top-4 z-10 bg-card/60 backdrop-blur-xl">
                <CardContent className="p-4 sm:p-6">
                    <label htmlFor='serverAddress' className="text-sm font-medium text-muted-foreground mb-2 block ml-1">Server Address</label>
                    <div className="flex flex-col sm:flex-row items-center gap-4">
                        <Input
                            ref={inputRef}
                            id="serverAddress"
                            name="serverAddress"
                            defaultValue={state.serverAddress ?? ''}
                            placeholder="e.g., hypixel.net"
                            className="text-base flex-grow h-16 px-4 bg-background/80"
                            aria-label="Server Address"
                            disabled={pending}
                        />
                        <SubmitButton />
                    </div>
                    {state.error && !state.status?.online && !pending && <p className="text-sm font-medium text-destructive mt-2">{state.error}</p>}
                </CardContent>
            </Card>
            
            <Results state={state} onRefresh={handleRefresh} isRefreshing={pending} onAutoRefreshToggle={handleAutoRefreshToggle} isAutoRefreshing={isAutoRefreshing} onFavoriteToggle={handleToggleFavorite} isFavorited={favorites.some(f => f.address === state.serverAddress)} playerHistory={playerHistory} />

          </form>
          
          <div className="space-y-8">
            <FavoriteServers favorites={favorites} onServerSelect={handleServerSelect} onSaveFavorite={handleSaveFavorite} onRemoveFavorite={handleRemoveFavorite} />
            
            <ServerHistory history={history} onServerSelect={handleServerSelect} onClearHistory={handleClearHistory} />

            <Separator className="bg-border/20" />

            <PopularServers onServerSelect={handleServerSelect} />
          </div>

        </main>
      </div>

      <footer className="py-8 mt-auto text-center text-muted-foreground text-sm">
        <p>Built with the love of the craft. 💎</p>
      </footer>
    </div>
  );
}
