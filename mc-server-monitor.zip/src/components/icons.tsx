import type { SVGProps } from 'react';

export function PickaxeIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M14 6l-4 4-3 11 11-3 4-4-8-8zM9 9l-2-2" />
      <path d="M13 4l-1.5 1.5M18 9l-1.5 1.5" />
    </svg>
  );
}


export function ServerIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <rect width="20" height="8" x="2" y="2" rx="2" ry="2" />
      <rect width="20" height="8" x="2" y="14" rx="2" ry="2" />
      <line x1="6" x2="6.01" y1="6" y2="6" />
      <line x1="6" x2="6.01" y1="18" y2="18" />
    </svg>
  );
}

export function UsersIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

export function PlayerAvatarIcon(props: SVGProps<SVGSVGElement>) {
    return (
        <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 8 8"
            shapeRendering="crispEdges"
            {...props}
        >
            <path stroke="#403020" d="M2 1h4M1 2h1M6 2h1M1 3h1M3 3h2M6 3h1M1 4h1M6 4h1M2 5h1M5 5h1M3 6h2" />
            <path stroke="#f0d0a0" d="M2 2h1M5 2h1M2 3h1M5 3h1" />
            <path stroke="#e0c090" d="M3 2h2" />
            <path stroke="#c0a070" d="M2 4h4" />
            <path stroke="#00f" d="M3 4h1M5 4h0" />
            <path stroke="#fff" d="M4 4h1" />
            <path stroke="#a00" d="M3 5h2" />
        </svg>
    )
}

export function StatusOnlineIcon(props: SVGProps<SVGSVGElement>) {
    return (
        <svg viewBox="0 0 10 10" width="1em" height="1em" {...props}>
            <circle cx="5" cy="5" r="5" fill="hsl(var(--status-online))" />
        </svg>
    );
}

export function StatusOfflineIcon(props: SVGProps<SVGSVGElement>) {
    return (
        <svg viewBox="0 0 10 10" width="1em" height="1em" {...props}>
            <circle cx="5" cy="5" r="5" fill="hsl(var(--status-offline))" />
        </svg>
    );
}
